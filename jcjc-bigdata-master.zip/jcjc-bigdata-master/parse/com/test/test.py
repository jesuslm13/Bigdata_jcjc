# -*- coding:utf-8 -*-


if __name__ == '__main__':
    
#     totalCount = 256
#     numOfRows = 100 # 한페이지의 결과 수
#     pageSize = int(totalCount/numOfRows) + 1 # 페이지 수
#     
#     print("totalCount :", totalCount, type(totalCount))
#     print("numOfRows :", numOfRows, type(numOfRows))
#     print("pageSize :", pageSize, type(pageSize))
#     
#     for i in range(pageSize):
#         print(i+1, "번쨰 페이지...")
#         for j in range(1, numOfRows):
#             print("\t", j, "번쨰 값")

    
    len = 10
    for i in range(10):
        print(i)